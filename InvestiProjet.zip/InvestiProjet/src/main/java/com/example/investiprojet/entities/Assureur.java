package com.example.investiprojet.entities;

import jakarta.persistence.OneToMany;

public class Assureur extends User{

    // @OneToMany(mappedBy = "approvedBy")
   // private List<Sinister> approvedSinisters; //
}
