package com.example.investiprojet.entities;

public enum InvestorStatus {
    ACTIVE,
    INACTIVE,
    PENDING,
    SUSPENDED
}

